import tarfile
import urllib.parse
from io import BytesIO
from mimetypes import guess_type
import boto3

s3 = boto3.client('s3')

def lambda_handler(event, context):
    bucket = event['Records'][0]['s3']['bucket']['name']
    tgz_key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'])

    try:
        # Get the zipfile from S3
        obj = s3.get_object(Bucket=bucket, Key=tgz_key)

        t = tarfile.open(fileobj=BytesIO(obj['Body'].read()))

        # Extract and upload each file in the zipfile
        for filename in t.getnames():
            # content_type = guess_type(filename, strict=False)[0]
            s3.upload_fileobj(
                Fileobj=t.extractfile(filename),
                Bucket=bucket,
                Key=filename
            )
    except Exception as e:
        print('Error getting object {zip_key} from bucket {bucket}.')
        raise e